<?


class Model_Admin{
	
	function get(){
		$sql = "SELECT * FROM `skills`";
		$result = DB::getSelect($sql);

		if ($result['count'] > 0) {
			return $result['result'];
		}
	}

	function update_skills($percent = 0, $id = 1){
		$sql = "UPDATE `skills` SET percent=:percent WHERE id=:id";
		$result = DB::getSelect($sql,array('percent' => $percent, 'id' => $id));

		if ($result['count'] > 0) {
			return $result['result'];
		}
	}
}