<?

require_once 'controller.php';

class Index extends Controller{};

