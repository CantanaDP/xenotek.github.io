<?

require_once 'controller.php';

class About extends Controller{};

