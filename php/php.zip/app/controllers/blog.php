<?

require_once 'controller.php';

class Blog extends Controller{};

