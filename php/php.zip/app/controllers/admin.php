<?

require_once 'controller.php';

class Admin extends Controller{};

