<?


$db_server = 'localhost';
$db_type = 'mysql';
$db_name = 'portfolio';
$db_user = 'root';
$db_password = '';