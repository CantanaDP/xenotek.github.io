<?


$db_server = 'localhost';
$db_type = 'mysql';
$db_name = 'cs89557_portf';
$db_user = 'cs89557_portf';
$db_password = 'onu72tor';