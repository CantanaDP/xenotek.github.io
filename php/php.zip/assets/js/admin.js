(function() {
  'use strict';


  $('.tabs__controls-link').on('click', function(e) {
    e.preventDefault();
    
    var item = $(this).closest('.tabs__controls-item'),
    		contentItem = $('.content__item'),
    		itemPosition = item.data('content');

   	contentItem.filter('.content__item--' + itemPosition)
   		.add(item)
   		.addClass('active')
   		.siblings()
   		.removeClass('active');

  });
  $('.files__input').on('change', function(event) {
    $('.files__button').text('Изображение');
  });


})();


//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkbWluLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoiYWRtaW4uanMiLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24oKSB7XHJcbiAgJ3VzZSBzdHJpY3QnO1xyXG5cclxuXHJcbiAgJCgnLnRhYnNfX2NvbnRyb2xzLWxpbmsnKS5vbignY2xpY2snLCBmdW5jdGlvbihlKSB7XHJcbiAgICBlLnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBcclxuICAgIHZhciBpdGVtID0gJCh0aGlzKS5jbG9zZXN0KCcudGFic19fY29udHJvbHMtaXRlbScpLFxyXG4gICAgXHRcdGNvbnRlbnRJdGVtID0gJCgnLmNvbnRlbnRfX2l0ZW0nKSxcclxuICAgIFx0XHRpdGVtUG9zaXRpb24gPSBpdGVtLmRhdGEoJ2NvbnRlbnQnKTtcclxuXHJcbiAgIFx0Y29udGVudEl0ZW0uZmlsdGVyKCcuY29udGVudF9faXRlbS0tJyArIGl0ZW1Qb3NpdGlvbilcclxuICAgXHRcdC5hZGQoaXRlbSlcclxuICAgXHRcdC5hZGRDbGFzcygnYWN0aXZlJylcclxuICAgXHRcdC5zaWJsaW5ncygpXHJcbiAgIFx0XHQucmVtb3ZlQ2xhc3MoJ2FjdGl2ZScpO1xyXG5cclxuICB9KTtcclxuICAkKCcuZmlsZXNfX2lucHV0Jykub24oJ2NoYW5nZScsIGZ1bmN0aW9uKGV2ZW50KSB7XHJcbiAgICAkKCcuZmlsZXNfX2J1dHRvbicpLnRleHQoJ9CY0LfQvtCx0YDQsNC20LXQvdC40LUnKTtcclxuICB9KTtcclxuXHJcblxyXG59KSgpO1xyXG5cclxuIl0sInNvdXJjZVJvb3QiOiIvc291cmNlLyJ9
